#!/usr/bin/env python
# coding: utf-8

from pyspark import SparkContext
import sys
import json
import re


def breaksentence(data):
    data=json.loads(data)
    l=list()
    if "reviewText" in data:
        x=re.findall(r'((?:[\.,!?;"])|(?:(?:\#|\@)?[A-Za-z0-9_\-]+(?:\'[a-z]{1,3})?))', data['reviewText'].lower())
        if len(x)>0:
            return (data['overall'],data['verified'],x)


sc = SparkContext.getOrCreate()
file = sys.argv[1]
#file = "C:\\Software_5.json.gz"
#print(file)
rdd = sc.textFile(file,100)
#print(rdd.take(2))
data=rdd.map(lambda x: breaksentence(x)).filter(lambda x: x!=None)
freq_data=data.flatMap(lambda x:x[2]).map(lambda x: (x,1)).reduceByKey(lambda a,b: a+b).sortBy(lambda x: x[1],ascending=False)




top_words=freq_data.map(lambda x: x[0])
words_set=top_words.take(1000)



def word_frequency_per_review(data,words_set):
    counts = dict((word,0) for word in words_set)
    l=list()
    for word in data[2]:
        if word in counts:
            counts[word] += 1
    for x in counts:
        l.append((x,counts[x]/len(data[2])))
    return (data[0],data[1],l)


thousand_word_per_review=data.map(lambda x: word_frequency_per_review(x,words_set))
#print(thousand_word_per_review.take(2))




def mapping_word_to_reviews(x):
    l=list()
    for word in x[2]:
        l.append((word[0],(word[1],x[0],x[1])))
    return l



reverse=thousand_word_per_review.flatMap(lambda x: mapping_word_to_reviews(x)).groupByKey().mapValues(list)


#print(reverse.take(1))



import numpy as np
from scipy import stats




def calculate_betas(data,single_variate):
    if single_variate==1:
        X=np.array([data[1][i][0] for i in range(0,len(data[1]))])
        Y=np.array([data[1][i][1] for i in range(0,len(data[1]))])

        X=(X-np.mean(X))/np.std(X)
        Y=(Y-np.mean(Y))/np.std(Y)
        
        X=X.reshape(-1,1)
        X=np.concatenate((np.ones(shape=X.shape[0]).reshape(-1,1),X),1)
        betas=np.linalg.inv(X.transpose().dot(X)).dot(X.transpose()).dot(Y)
        
        Y_hat=list()
        error=list()
        
        for xi in X:
            pred=betas[0]+betas[1]*xi[1]
            Y_hat.append(pred)
        error=Y_hat-Y
        rss=np.sum([error**2])
        t=betas[1]/(np.sqrt(rss/((X.shape[0]-2))/np.sum((X[:,1]-np.mean(X[:,1]))**2)))
        
        pvalue= stats.t.sf(abs(t), X.shape[0]-2) * 2 *1000
    else:
        X1=np.array([data[1][i][0] for i in range(0,len(data[1]))])
        Y=np.array([data[1][i][1] for i in range(0,len(data[1]))])
        
        X2=list()
        for x in data[1]:
            if x[2]==False:
                X2.append(0)
            else:
                X2.append(1)
        
        X1=(X1-np.mean(X1))/np.std(X1)
        X2=(X2-np.mean(X2))/np.std(X2)
                
        X=np.column_stack((X1,X2))
        
        
        Y=(Y-np.mean(Y))/np.std(Y)
        
        X=np.concatenate((np.ones(shape=X.shape[0]).reshape(-1,1),X),1)
        betas=np.linalg.inv(X.transpose().dot(X)).dot(X.transpose()).dot(Y)
        
        Y_hat=list()
        error=list()
        
        for xi in X:
            pred=betas[0]+betas[1]*xi[1]+betas[2]*xi[2]
            Y_hat.append(pred)
        error=Y_hat-Y
        rss=np.sum([i ** 2 for i in error])
        t=betas[1]/(np.sqrt(rss/((X.shape[0]-3))/np.sum((X[:,1]-np.mean(X[:,1]))**2)))
        pvalue= stats.t.sf(abs(t), X.shape[0]-3) * 2 *1000

    return (data[0],betas,pvalue)
    



one=reverse.map(lambda x: calculate_betas(x,1))
two=reverse.map(lambda x: calculate_betas(x,0))
pvalues_top_wo_verfied=one.sortBy(lambda x: x[1][1],ascending=False)
pvalues_top_verfied=two.sortBy(lambda x: x[1][1],ascending=False)

pvalues_bottom_wo_verfied=one.sortBy(lambda x: x[1][1],ascending=True)
pvalues_bottom_verfied=two.sortBy(lambda x: x[1][1],ascending=True)


print("The top 20 word positively correlated with rating - ('word',[beta values], pvalue)")
print(pvalues_top_wo_verfied.take(20))
print("-----------------------------------------------------------------------------------")

print("The top 20 word negatively correlated  with rating - ('word',[beta values], pvalue)")
print(pvalues_bottom_wo_verfied.take(20))
print("-----------------------------------------------------------------------------------")

print("The top 20 words positively related to rating, controlling for verified - ('word',[beta values], pvalue)")
print(pvalues_top_verfied.take(20))
print("-----------------------------------------------------------------------------------")

print("The top 20 words negatively related to rating, controlling for verified - ('word',[beta values], pvalue)")
print(pvalues_bottom_verfied.take(20))
print("-----------------------------------------------------------------------------------")
