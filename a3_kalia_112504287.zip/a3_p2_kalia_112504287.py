#!/usr/bin/env python
# coding: utf-8

# In[1]:


from pyspark import SparkContext
import sys
import json
import numpy as np


sc = SparkContext.getOrCreate()
file = sys.argv[1]
#print(file)
#file = "C:\\Software_5.json.gz"
#print(file)
rdd = sc.textFile(file).map(json.loads)
filter1=rdd.map(lambda x: ((x['reviewerID'],x['asin']),x['overall'])).groupByKey().mapValues(list).map(lambda x: (x[0],x[1][len(x[1])-1]))



#print(filter1.take(2))



filter2=filter1.map(lambda x: (x[0][1],(x[0][0],x[1]))).groupByKey().mapValues(list).filter(lambda x: len(x[1]) >= 25)



#print(filter2.count())



def user_to_data(x):
    l=list()
    for user,rating in x[1]:
        l.append((user,(x[0],rating)))
    return l
        



filter3=filter2.flatMap(lambda x: user_to_data(x)).groupByKey().mapValues(list).filter(lambda x: len(x[1]) >= 5)


#print(filter3.take(1))



items=filter3.flatMap(lambda x: user_to_data(x)).groupByKey().mapValues(list)


def mean_center(data):
    avg_rating=0
    total=0
    for user,rating in data[1]:
        total+=1
        avg_rating+=rating
    avg_rating=avg_rating/total
    
    l=list()
    for user,rating in data[1]:
        new_rating=rating-avg_rating
        l.append((user,new_rating,rating))
    return (data[0],l)
        


items=items.map(lambda x: mean_center(x))


#print(items.take(2))


for target_item in eval(sys.argv[2]):
#target_item='B00EZPXYP4'
    #print(target_item)

    item1=items.filter(lambda x: x[0]==target_item).collect()
    items_all=items.filter(lambda x: x[0]!=target_item)
    
    
    #print(item1) #item,list of tuple(user,rating)
    
    
    
    dictionary=dict()
    rating_sqrt=0.0
    for user,rating,old_rating in item1[0][1]:
        rating_sqrt+=rating*rating
        dictionary[user]=rating
    rating_sqrt=np.sqrt(rating_sqrt)
    dictionary=sc.broadcast(dictionary)
    rating_sqrt=sc.broadcast(rating_sqrt)
    
    
    def calculate_similarity(data):
        curr_rating_sqrt=0.0
        sum_of_square=0.0
        common=0
        for user,rating,old_rating in data[1]:
            curr_rating_sqrt+=rating*rating
            if user in dictionary.value:
                common+=1
                sum_of_square+=rating*dictionary.value[user]
        
        if curr_rating_sqrt==0.0:
            sim=0.0
        else:
            sim=sum_of_square/(np.sqrt(curr_rating_sqrt)*rating_sqrt.value)
        return (sim,common,data[0],data[1])
    
    
    
    similarity=items_all.map(lambda x: calculate_similarity(x)).filter(lambda x: x[1]>=2 and x[0]>0).sortBy(lambda x: x[0],ascending=False).take(50) #similarity,item,list of users
    similarity=sc.parallelize(similarity)
    
    
    
    #print(similarity.take(1))
    
    
    def creater_user_to_items(data):
        l=list()
        user_list=data[3]
        for user in user_list:
            l.append((user[0],(data[0],data[2],user[1],user[2])))
        return l
    
    
    user_to_items=similarity.flatMap(lambda x: creater_user_to_items(x)).groupByKey().mapValues(list).filter(lambda x: len(x[1])>=2 and x[0] not in dictionary.value)
    
    
    
    #print(user_to_items.take(1))
    
    
    def make_predictions(data):
        sum_numerator=0.0
        sum_denominator=0.0
        for items in data[1]:
            sum_numerator+=items[0]*items[3]
            sum_denominator+=items[0]
        return ((data[0],sum_numerator/sum_denominator))
                
    
    
    user_predictions=user_to_items.map(lambda x: make_predictions(x))
    print("user predictions for ",target_item," (user,rating)")
    print(user_predictions.collect())
    print("----------------------------------------------------------")
    

